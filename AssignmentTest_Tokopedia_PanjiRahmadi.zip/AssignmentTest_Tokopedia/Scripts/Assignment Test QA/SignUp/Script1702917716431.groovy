import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

// Sebelum buka apliasi, pastikan aplikasi tokopedia sudah di download
Mobile.startExistingApplication('com.tokopedia.tkpd', FailureHandling.STOP_ON_FAILURE)

Mobile.tap(findTestObject('SignUp/BarMenuUtama'), 0)

Mobile.tap(findTestObject('SignUp/ButtonDaftar'), 0)

// Persiapkan Email atau No Handphone yang belum terdaftar
Mobile.setText(findTestObject('SignUp/TextInputNomorHPatauE-mail'), 'kamox53457@astegol.com', 0)

// Kondisi negatif ketika salah input no handphone
// Jika ingin kondisi ini di eksekusi, masukkan no handphone pada step sebelumnya kurang dari 6 digit.
if (Mobile.waitForElementPresent(findTestObject('Object Repository/SignUp/Error Message NoHp'), 2)) {
    Mobile.verifyElementText(findTestObject('Object Repository/SignUp/Error Message NoHp'), 'Min. 6 digit')

    Mobile.clearText(findTestObject('Object Repository/SignUp/TextInputNomorHPatauE-mail'), 0)

    Mobile.setText(findTestObject('Object Repository/SignUp/TextInputNomorHPatauE-mail'), '08xxxxxxxxxxx', 0)
}

Mobile.tap(findTestObject('SignUp/ButtonLanjut'), 0)

// Karena untuk input kode OTP manual, pastikan cek email untuk melihat kode OTPnya
Mobile.tap(findTestObject('SignUp/ButtunKirimOTP'), 0)

Mobile.delay(30)

Mobile.tap(findTestObject('SignUp/NamaLengkap'), 0)

Mobile.tap(findTestObject('SignUp/NamaLengkap'), 0)

Mobile.setText(findTestObject('SignUp/NamaLengkapSetelahTap'), 'Yss Lambada', 0)

Mobile.delay(2)

Mobile.tap(findTestObject('SignUp/KataSandi'), 0)

Mobile.setText(findTestObject('SignUp/KataSandiSetelahTap'), 'lambada123', 0)

Mobile.delay(2)

Mobile.tap(findTestObject('SignUp/ButtonDaftarSetelahKataSandi'), 0)

Mobile.delay(2)

Mobile.doubleTap(findTestObject('SignUp/ButtonBack'), 0)

Mobile.verifyElementText(findTestObject('SignUp/TextView - Silver'), 'Silver')

WebUI.callTestCase(findTestCase('Assignment Test QA/LogOut'), [:], FailureHandling.STOP_ON_FAILURE)

