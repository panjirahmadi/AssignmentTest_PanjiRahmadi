import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

// Sebelum buka apliasi, pastikan aplikasi tokopedia sudah di download
Mobile.startExistingApplication('com.tokopedia.tkpd', FailureHandling.STOP_ON_FAILURE)

Mobile.tap(findTestObject('LogIn/BarMenuUtama'), 0)

Mobile.tap(findTestObject('LogIn/ButtonMasuk'), 0)

Mobile.setText(findTestObject('LogIn/TextInputNomorHPatauE-mail'), 'mamatsentosa7@gmail.com', 0)

Mobile.tap(findTestObject('LogIn/ButtonLanjut'), 0)

Mobile.tap(findTestObject('Object Repository/LogIn/Button Metode verifikasi - OTP via E-mail'), 0, FailureHandling.STOP_ON_FAILURE)

Mobile.delay(30)

// Kondisi negatif case, Ketika user salah input OTP Email
if (Mobile.waitForElementPresent(findTestObject('Object Repository/LogIn/Error Massage OTP Email salah'), 2)) {
	Mobile.verifyElementText(findTestObject('Object Repository/LogIn/Error Massage OTP Email salah'), 'OTP salah, silahkan coba lagi')
	Mobile.clearText(findTestObject('Object Repository/LogIn/Metode Verifikasi - InputKedeOTPEmail'), 0)
	Mobile.delay(15)
}

//Ini adalah kondisi ketika akun user belum connect nomor handphone
if (Mobile.waitForElementPresent(findTestObject('Object Repository/LogIn/BackButton'), 0)) {
	Mobile.verifyElementExist(findTestObject('Object Repository/LogIn/BackButton'), 0)
	Mobile.doubleTap(findTestObject('LogIn/BackButton'), 0)	
}

Mobile.tap(findTestObject('LogIn/BarMenuUtama'), 0)

Mobile.tap(findTestObject('LogIn/CardButtonProfile'), 0, FailureHandling.STOP_ON_FAILURE)

Mobile.verifyElementExist(findTestObject('LogIn/ProfilePageAkun Saya'), 0)